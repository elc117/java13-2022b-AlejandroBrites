package ch.song;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;



public class PrimaryController {
    
    @FXML TextField nomeText;
    @FXML TextField artistaText;
    @FXML TextField userText;
    @FXML TextField urlText;
    @FXML TextField tagText;
    @FXML Label greeting;
    
    private Song Song;
    
    @FXML
    void doGreeting(ActionEvent event) {
        
        Song = new Song();
        
        Song.setName(nomeText.getText());
        Song.setArtist(artistaText.getText());
        Song.setUser(userText.getText());
        Song.setUrl(urlText.getText());
        Song.setTags(tagText.getText());
        
        String message = Song.toString();
        greeting.setText(message);
    }
}